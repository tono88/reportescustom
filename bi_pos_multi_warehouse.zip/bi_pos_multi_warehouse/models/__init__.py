# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import product_product_inherit
from . import stock_quant
from . import pos_config
from . import res_config_settings
from . import stock_warehouse
from . import pos_session
from . import stock_picking