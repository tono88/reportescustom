Version : 18.0.0.1 (17/02/2025)
	- fixed issue for improvement related to product variant popup.

Version : 18.0.0.2 (24/02/2025)
	- modify string for "Default Stock Location".

Version : 18.0.0.3 (07/03/2025)
	- fixes issue more then 2 product add.